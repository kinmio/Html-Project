$(document).ready(function() {

  $('.header').click(function(event) {
    /* Act on the event */
    $('body').toggleClass('open');
  });

});